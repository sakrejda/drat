#ifndef STAN__MATH__PRIM_HPP
#define STAN__MATH__PRIM_HPP

#include <stan/math/prim/arr.hpp>
#include <stan/math/prim/mat.hpp>
#include <stan/math/prim/scal.hpp>

#endif
