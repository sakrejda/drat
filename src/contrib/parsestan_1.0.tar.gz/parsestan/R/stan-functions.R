

segment <- function(x,i,n) return(x[i:(i+n-1)])
num_elements <- length


