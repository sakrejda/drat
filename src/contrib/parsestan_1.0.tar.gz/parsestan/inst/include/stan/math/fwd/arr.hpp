#ifndef STAN__MATH__FWD__ARR_HPP
#define STAN__MATH__FWD__ARR_HPP

#include <stan/math/fwd/core.hpp>
#include <stan/math/fwd/arr/fun/log_sum_exp.hpp>

#endif
