

## Schema
## original_data, name_matched_data, type_matched_data, output_data

# original_data : it's all text no matter what anyone claims.
# name_matched_data : matched up column names.
# type_matched_data : did type conversion and dropped extraneous columns
# output_data : purpose-specific subsets and aggregated data sets.

