#ifndef STAN__INTERFACE__VAR_CONTEXT_FACTORY__HPP
#define STAN__INTERFACE__VAR_CONTEXT_FACTORY__HPP

#include <stan/interface/var_context_factory/var_context_factory.hpp>
#include <stan/interface/var_context_factory/dump_factory.hpp>

#endif
