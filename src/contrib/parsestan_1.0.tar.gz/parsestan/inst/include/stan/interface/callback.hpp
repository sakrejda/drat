#ifndef STAN__INTERFACE__CALLBACK__HPP
#define STAN__INTERFACE__CALLBACK__HPP

#include <stan/interface/callback/callback.hpp>
#include <stan/interface/callback/noop_callback.hpp>

#endif
